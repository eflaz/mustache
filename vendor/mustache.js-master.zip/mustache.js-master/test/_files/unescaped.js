({
  title: function () {
    return "Bear > Shark";
  },
  symbol: null
})
